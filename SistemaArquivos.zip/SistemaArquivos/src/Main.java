public class Main {
    public static void main(String[] args) {
        FileSystem fs = new FileSystem();

        // Criar diretórios e arquivos
        fs.createDirectory("/home");
        fs.createDirectory("/home/user");
        fs.createFile("/home/user/arquivo1.txt", "Conteúdo do arquivo 1");
        fs.createFile("/home/user/arquivo2.txt", "Conteúdo do arquivo 2");

        // Listar conteúdo do diretório /home/user
        System.out.println("Conteúdo de /home/user:");
        fs.listDirectory("/home/user");
        System.out.println();

        // Renomear um arquivo
        fs.renameFile("/home/user/arquivo1.txt", "/home/user/novo.txt");

        // Listar novamente para verificar a mudança
        System.out.println("Conteúdo de /home/user após renomeação de arquivo1.txt para novo.txt:");
        fs.listDirectory("/home/user");
        System.out.println();

        // Copiar um arquivo
        fs.copyFile("/home/user/novo.txt", "/home/user/copiado.txt");

        // Listar novamente para verificar a cópia
        System.out.println("Conteúdo de /home/user após cópia de novo.txt para copiado.txt:");
        fs.listDirectory("/home/user");
        System.out.println();

        // Deletar um arquivo
        fs.deleteFile("/home/user/arquivo2.txt");

        // Listar novamente para verificar a deleção
        System.out.println("Conteúdo de /home/user após deleção de arquivo2.txt:");
        fs.listDirectory("/home/user");
        System.out.println();

        // Renomear um diretório
        fs.renameDirectory("/home/user", "/home/user2");

        // Listar novamente para verificar a mudança de nome do diretório
        System.out.println("Conteúdo de /home após renomeação de /home/user para /home/user2:");
        fs.listDirectory("/home");
        System.out.println();

        // Deletar um diretório
        fs.deleteDirectory("/home/user2");

        // Listar novamente para verificar a deleção do diretório
        System.out.println("Conteúdo de /home após deleção de /home/user2:");
        fs.listDirectory("/home");
        System.out.println();
    }
}
